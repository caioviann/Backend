const express = require('express');
const sequelize = require('./config/db');
const Recipe = require('./models/Recipe');
const Ingredient = require('./models/Ingredient');
const Instruction = require('./models/Instruction');
const Tag = require('./models/Tag');

const app = express();
app.use(express.json());

// GET /receitas retorna todas as receitas com ingredientes, instruções e tags
app.get('/receitas', async (req, res) => {
  try {
    const recipe = await Recipe.findAll({
      include: [Ingredient, Instruction, Tag]
    });
    res.json(recipe);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao buscar receitas');
  }
});

// GET /receitas/:id – retorna receita específica
app.get('/receitas/:id', async (req, res) => {
  try {
    const recipe = await Recipe.findByPk(req.params.id, {
      include: [Ingredient, Instruction, Tag]
    });
    if (!recipe) return res.status(404).send('Receita não encontrada');
    res.json(recipe);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao buscar receita');
  }
});

// PUT /receitas/:id – atualiza receita por ID
app.put('/receitas/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const {
      name,
      prepTimeMinutes,
      cookTimeMinutes,
      servings,
      difficulty,
      cuisine,
      caloriesPerServing,
      userId,
      image,
      rating,
      reviewCount,
      mealType,
      ingredients,
      instructions,
      tags
    } = req.body;

    const recipe = await Recipe.findByPk(id);
    if (!recipe) return res.status(404).send('Receita não encontrada');

    await receita.update({
      name,
      prepTimeMinutes,
      cookTimeMinutes,
      servings,
      difficulty,
      cuisine,
      caloriesPerServing,
      userId,
      image,
      rating,
      reviewCount,
      mealType
    });

    await Ingredient.destroy({ where: { recipeId: id } });
    await Instruction.destroy({ where: { recipeId: id } });
    await Tag.destroy({ where: { recipeId: id } });

    if (ingredients?.length) {
      const ingredientsData = ingredients.map(content => ({ content, recipeId: id }));
      await Ingredient.bulkCreate(ingredientsData);
    }

    if (instructions?.length) {
      const instructionsData = instructions.map(step => ({ step, recipeId: id }));
      await Instruction.bulkCreate(instructionsData);
    }

    if (tags?.length) {
      const tagsData = tags.map(name => ({ name, recipeId: id }));
      await Tag.bulkCreate(tagsData);
    }

    res.status(200).send();
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao atualizar receita');
  }
});

// POST /receitas/adicionar – adiciona uma nova receita
app.post('/receitas/adicionar', async (req, res) => {
  try {
    const {
      name,
      prepTimeMinutes,
      cookTimeMinutes,
      servings,
      difficulty,
      cuisine,
      caloriesPerServing,
      userId,
      image,
      rating,
      reviewCount,
      mealType,
      ingredients,
      instructions,
      tags
    } = req.body;

    const recipe = await Recipe.create({
      name,
      prepTimeMinutes,
      cookTimeMinutes,
      servings,
      difficulty,
      cuisine,
      caloriesPerServing,
      userId,
      image,
      rating,
      reviewCount,
      mealType
    });
// não ta adicionando ingreentes
    if (Array.isArray(ingredients) && ingredients.length) {
      const ingredientData = ingredients.map(content => ({ content, recipeId: recipe.id }));
      await Ingredient.bulkCreate(ingredientData);
    }

    if (Array.isArray(instructions) && instructions.length) {
      const instructionData = instructions.map(step => ({ step, recipeId: recipe.id }));
      await Instruction.bulkCreate(instructionData);
    }

    if (tags?.length) {
      const tagData = tags.map(name => ({ name, recipeId: recipe.id }));
      await Tag.bulkCreate(tagData);
    }

    res.status(200).send();
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao adicionar receita');
  }
});

app.listen(3000, async () => {
  await sequelize.sync();
  console.log('Servidor rodando na porta 3000');
});
